Pfile=fopen('b.dat');
x=fread(Pfile,8);
fclose('all');