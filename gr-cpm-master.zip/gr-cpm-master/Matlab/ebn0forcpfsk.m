Ebn0db=6:2:14;
Ebn0=10.^(Ebn0db./10);
BER=qfunc(2*sqrt(Ebn0));